import express from 'express';

const app = express();
const PORT = process.env.PORT || 3000;
const KALSHI = process.env.KALSHI_API_BASE || 'https://external-api.kalshi.com/trade-api/v2';
const SCHEDULE_URL = 'https://raw.githubusercontent.com/nflverse/nfldata/master/data/games.csv';

let scheduleCache = { at: 0, data: [] };
let marketCache = { at: 0, data: [] };
const TTL = 5 * 60 * 1000;

const teamNames = {
  ARI:'Arizona Cardinals', ATL:'Atlanta Falcons', BAL:'Baltimore Ravens', BUF:'Buffalo Bills', CAR:'Carolina Panthers', CHI:'Chicago Bears', CIN:'Cincinnati Bengals', CLE:'Cleveland Browns', DAL:'Dallas Cowboys', DEN:'Denver Broncos', DET:'Detroit Lions', GB:'Green Bay Packers', HOU:'Houston Texans', IND:'Indianapolis Colts', JAX:'Jacksonville Jaguars', KC:'Kansas City Chiefs', LA:'Los Angeles Rams', LAC:'Los Angeles Chargers', LV:'Las Vegas Raiders', MIA:'Miami Dolphins', MIN:'Minnesota Vikings', NE:'New England Patriots', NO:'New Orleans Saints', NYG:'New York Giants', NYJ:'New York Jets', PHI:'Philadelphia Eagles', PIT:'Pittsburgh Steelers', SEA:'Seattle Seahawks', SF:'San Francisco 49ers', TB:'Tampa Bay Buccaneers', TEN:'Tennessee Titans', WAS:'Washington Commanders'
};

function parseCsvLine(line){
  const out=[]; let cur='', q=false;
  for(let i=0;i<line.length;i++){
    const c=line[i];
    if(c==='"' && line[i+1]==='"'){cur+='"';i++;continue;}
    if(c==='"'){q=!q;continue;}
    if(c===',' && !q){out.push(cur);cur='';} else cur+=c;
  }
  out.push(cur); return out;
}
function csvToObjects(csv){
  const lines=csv.trim().split(/\r?\n/); if(!lines.length) return [];
  const headers=parseCsvLine(lines[0]);
  return lines.slice(1).map(l=>{const v=parseCsvLine(l);return Object.fromEntries(headers.map((h,i)=>[h,v[i]??'']));});
}
function isoDate(s){
  if(!s) return null;
  const d=new Date(s); return Number.isNaN(d.getTime())?null:d.toISOString();
}
function scheduleId(g){ return `${g.season}-${g.week}-${g.away_team}-${g.home_team}`; }
function normalize(s){return String(s||'').toLowerCase().replace(/[^a-z0-9]/g,'');}

async function getSchedule(){
  if(Date.now()-scheduleCache.at<TTL && scheduleCache.data.length) return scheduleCache.data;
  const r=await fetch(SCHEDULE_URL); if(!r.ok) throw new Error(`Schedule source ${r.status}`);
  const rows=csvToObjects(await r.text());
  const currentYear=new Date().getUTCFullYear();
  const games=rows.filter(g=>Number(g.season)===currentYear).map(g=>({
    id:scheduleId(g), season:Number(g.season), week:g.week, type:g.game_type,
    date:isoDate(g.gameday || g.start_time || g.game_date),
    away:g.away_team, home:g.home_team,
    awayName:teamNames[g.away_team]||g.away_team, homeName:teamNames[g.home_team]||g.home_team,
    location:g.location||'', stadium:g.stadium||'', roof:g.roof||'',
    awayScore:g.away_score?Number(g.away_score):null, homeScore:g.home_score?Number(g.home_score):null,
    status:g.result ? 'final' : 'scheduled'
  }));
  scheduleCache={at:Date.now(),data:games}; return games;
}

async function getKalshiMarkets(){
  if(Date.now()-marketCache.at<TTL && marketCache.data.length) return marketCache.data;
  const u=new URL(`${KALSHI}/markets`); u.searchParams.set('limit','200'); u.searchParams.set('status','open');
  const r=await fetch(u); if(!r.ok) throw new Error(`Kalshi ${r.status}`);
  const j=await r.json();
  const markets=(j.markets||[]).map(m=>({
    ticker:m.ticker,eventTicker:m.event_ticker,title:m.title||'',subtitle:m.subtitle||'',
    yesBid:Number(m.yes_bid_dollars ?? 0),yesAsk:Number(m.yes_ask_dollars ?? 0),last:Number(m.last_price_dollars ?? 0),
    volume:Number(m.volume_fp ?? 0),volume24h:Number(m.volume_24h_fp ?? 0),liquidity:Number(m.liquidity_dollars ?? 0),
    closeTime:m.close_time,updated:m.updated_time
  }));
  marketCache={at:Date.now(),data:markets}; return markets;
}

function matchMarkets(games, markets){
  return games.map(g=>{
    const aliases=[normalize(g.away),normalize(g.home),normalize(g.awayName),normalize(g.homeName)];
    const related=markets.filter(m=>{
      const t=normalize(`${m.title} ${m.subtitle}`);
      const hits=aliases.filter(a=>a && t.includes(a)).length;
      return hits>=1 && /(nfl|football|bills|patriots|chiefs|cowboys|eagles|ravens|49ers|packers|lions|bengals|browns|broncos|dolphins|jets|giants|commanders|steelers|texans|colts|jaguars|titans|vikings|bears|falcons|panthers|saints|buccaneers|cardinals|rams|chargers|raiders|seahawks)/i.test(`${m.title} ${m.subtitle}`);
    }).slice(0,20);
    return {...g,markets:related};
  });
}

app.get('/api/health',(req,res)=>res.json({ok:true,time:new Date().toISOString()}));
app.get('/api/schedule',async(req,res)=>{
  try{
    const games=await getSchedule();
    const week=req.query.week;
    res.json({source:'nflverse',updatedAt:new Date(scheduleCache.at).toISOString(),games:week?games.filter(g=>String(g.week)===String(week)):games});
  }catch(e){res.status(502).json({error:e.message});}
});
app.get('/api/markets',async(req,res)=>{
  try{res.json({source:'kalshi',updatedAt:new Date(marketCache.at||Date.now()).toISOString(),markets:await getKalshiMarkets()});}
  catch(e){res.status(502).json({error:e.message,markets:[]});}
});
app.get('/api/games',async(req,res)=>{
  try{const [games,markets]=await Promise.all([getSchedule(),getKalshiMarkets().catch(()=>[])]);res.json({updatedAt:new Date().toISOString(),games:matchMarkets(games,markets)});}
  catch(e){res.status(502).json({error:e.message});}
});
app.use(express.static('public'));
app.get('*',(req,res)=>res.sendFile(new URL('./public/index.html',import.meta.url).pathname));
app.listen(PORT,()=>console.log(`Co-Lays live server on http://localhost:${PORT}`));
