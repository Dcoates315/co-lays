# Co-Lays — Live MVP

This version upgrades the static demo into a real server-backed NFL dashboard.

## Live now
- NFL schedule: pulls the current season schedule from nflverse on the server and refreshes every 5 minutes.
- Kalshi: pulls open public markets from the Kalshi API on the server and attempts to match NFL markets to scheduled games.
- No API keys are placed in browser code.

## Important production step
The schedule source here is suitable for a technical MVP, but it is not a substitute for a commercial NFL data license. For production/commercial launch, plug a licensed feed such as Genius Sports into `getSchedule()` / a dedicated provider module.

Kalshi's public market endpoints can supply market quotes; private trading endpoints require authenticated credentials and should remain server-side.

## Run locally
1. Install Node 20+.
2. `npm install`
3. Copy `.env.example` to `.env` if desired.
4. `npm start`
5. Open `http://localhost:3000`

## Deploy
This is a normal Node/Express app and can be deployed to a Node-capable host. Set the same environment variables there. Do not commit private API keys.

## Next production upgrades
- Licensed NFL/Genius Sports feed
- PostgreSQL snapshots for historical prices/stats
- Injuries/weather/player stats
- Validated probability models and simulations
- Backtesting/calibration dashboard
- Real market execution-cost calculations
- User accounts and alerts
